package complex;

public class Main {

    public static void main(String[] args) {
        Complex a = new Complex(new int[]{1, 2});
    }
}
